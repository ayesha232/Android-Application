package com.example.bookme;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    EditText ed1, ed2, ed3, ed4;
    Button b1,b2;
    Spinner spinner1, spinner2;
    ListView lst1;

    ArrayAdapter arrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner mySpinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.BusService));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);

        Spinner mySpinner2 = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<String> myAdapter2 = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.BusService2));
        myAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner2.setAdapter(myAdapter2);

        b1 = findViewById(R.id.button1);
        b2 = findViewById(R.id.button2);
        spinner1 = findViewById(R.id.spinner);
        spinner2 = findViewById(R.id.spinner2);
        ed3 = findViewById(R.id.busdate);
        ed4 = findViewById(R.id.busservice);
        lst1 = findViewById(R.id.lst1);

        readdata();
        //createtable();

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               addrecord();

            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear();

            }
        });
    }

    public void readdata()
    {
        ArrayList<HashMap<String, String>> userList = GetUsers();

        ArrayAdapter<HashMap<String, String>> arrayAdapter = new ArrayAdapter<HashMap<String, String>>(
                this,
                android.R.layout.simple_list_item_1,
                userList );
        lst1.setAdapter (arrayAdapter);
    }

    public  void  createtable()
    {
        SQLiteDatabase db = openOrCreateDatabase("SliteDb", Context.MODE_PRIVATE, null);

        String sqlcreate = "create table searchdata(fromlocation text ,fromto text  ,date text ,busservice text)";
        db.execSQL(sqlcreate);

    }
    public  void  clear()
    {
        SQLiteDatabase db = openOrCreateDatabase("SliteDb", Context.MODE_PRIVATE, null);
        String s = "delete from  searchdata";
        db.execSQL(s);
        Toast.makeText(this, "search clear", Toast.LENGTH_LONG).show();

        readdata();
}

    public void addrecord() {
        try {

            String from = spinner1.getSelectedItem().toString();
            String to = spinner2.getSelectedItem().toString();
            String date = ed3.getText().toString();
            String busservice = ed4.getText().toString();
            //L1.setText("From:\t" + from + "\nTo:\t" + to + "\nDate:\t" + date + "\nBus Service:\t" + busservice);
            SQLiteDatabase db = openOrCreateDatabase("SliteDb", Context.MODE_PRIVATE, null);
            //String s = "delete from  searchdata";
            //db.execSQL(s);
            //String sqlcreate = "create table searchdata(fromlocation text ,fromto text  ,date text ,busservice text)";
            //db.execSQL(sqlcreate);

            String sql = "insert into  searchdata (fromlocation  ,fromto   ,date  ,busservice ) values (?,?,?,?)";
            SQLiteStatement statement = ((SQLiteDatabase) db).compileStatement(sql);
            statement.bindString(1, from);
            statement.bindString(2, to);
            statement.bindString(3, date);
            statement.bindString(4, busservice);
            statement.execute();
            Toast.makeText(this, "Record added", Toast.LENGTH_LONG).show();
            readdata();


        } catch (Exception ex) {
            Toast.makeText(this, "Record Fail", Toast.LENGTH_LONG).show();
        }
    }

    public ArrayList<HashMap<String, String>> GetUsers(){
        SQLiteDatabase db = openOrCreateDatabase("SliteDb", Context.MODE_PRIVATE, null);
        ArrayList<HashMap<String, String>> userList = new ArrayList<>();
        String query = "SELECT *  FROM searchdata";
        Cursor cursor = db.rawQuery(query,null);
        while (cursor.moveToNext()){
            HashMap<String,String> user = new HashMap<>();

            user.put("fromlocation",cursor.getString(cursor.getColumnIndexOrThrow("fromlocation")));
            user.put("fromto",cursor.getString(cursor.getColumnIndexOrThrow("fromto")));
            user.put("date",cursor.getString(cursor.getColumnIndexOrThrow("date")));
            user.put("busservice",cursor.getString(cursor.getColumnIndexOrThrow("busservice")));
            userList.add(user);
        }
        return  userList;
    }
}



