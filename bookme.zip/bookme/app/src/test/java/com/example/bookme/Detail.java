package com.example.bookme;

public class Detail {
}
